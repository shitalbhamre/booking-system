from django.db import models
from django.utils.dateparse import parse_date

class Inventory(models.Model):
    title = models.CharField(max_length=255)
    description = models.TextField(blank=True, null=True)
    remaining_count = models.IntegerField(default=0)
    expiration_date = models.DateField()

    def __str__(self):
        return self.title
