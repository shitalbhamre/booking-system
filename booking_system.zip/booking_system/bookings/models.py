from django.db import models
from django.utils.timezone import now
from members.models import Member
from inventory.models import Inventory

class Booking(models.Model):
    member = models.ForeignKey(Member, on_delete=models.CASCADE)
    item = models.ForeignKey(Inventory, on_delete=models.CASCADE)
    booking_date = models.DateTimeField(default=now)

    def __str__(self):
        return f"{self.member.name} booked {self.item.title} on {self.booking_date}"
