from django.shortcuts import get_object_or_404
from django.http import JsonResponse
from django.views import View
from django.utils.timezone import now
from django.utils.decorators import method_decorator
from django.views.decorators.csrf import csrf_exempt
import json

from members.models import Member
from inventory.models import Inventory
from .models import Booking

MAX_BOOKINGS = 2  # Maximum bookings allowed per member

@method_decorator(csrf_exempt, name='dispatch')
class BookItemView(View):
    def post(self, request, *args, **kwargs):
        """Handles booking an item for a member."""
        try:
            data = json.loads(request.body)
            member_id = data.get("member_id")
            inventory_id = data.get("inventory_id")

            if not member_id or not inventory_id:
                return JsonResponse({"error": "member_id and inventory_id are required"}, status=400)

            # Fetch the member and inventory item
            member = get_object_or_404(Member, id=member_id)
            inventory_item = get_object_or_404(Inventory, id=inventory_id)

            # Check if the member has reached max bookings
            current_bookings = member.booking_count
            if current_bookings >= MAX_BOOKINGS:
                return JsonResponse({"error": "Member has reached the maximum allowed bookings."}, status=400)

            # Check if the inventory item is available
            if inventory_item.remaining_count <= 0:
                return JsonResponse({"error": "No stock available for this item."}, status=400)

            # Create the booking
            booking = Booking.objects.create(
                member=member,
                item=inventory_item,
                booking_date=now()
            )

            # Update inventory count
            inventory_item.remaining_count -= 1
            inventory_item.save()

            return JsonResponse({
                "message": "Booking successful!",
                "booking_id": booking.id,
                "member_id": booking.member.id,
                "inventory_id": booking.item.id,
                "booking_date": booking.booking_date.strftime("%Y-%m-%d %H:%M:%S"),
            })

        except json.JSONDecodeError:
            return JsonResponse({"error": "Invalid JSON data"}, status=400)

        except Exception as e:
            return JsonResponse({"error": str(e)}, status=500)


@method_decorator(csrf_exempt, name='dispatch')
class CancelBookingView(View):
    def post(self, request, *args, **kwargs):
        """Handles canceling a booking based on booking reference."""
        try:
            data = json.loads(request.body)
            booking_id = data.get("booking_id")

            if not booking_id:
                return JsonResponse({"error": "booking_id is required"}, status=400)

            # Fetch the booking
            booking = get_object_or_404(Booking, id=booking_id)

            # Restore inventory count
            inventory_item = booking.item
            inventory_item.remaining_count += 1
            inventory_item.save()

            # Delete the booking record
            booking.delete()

            return JsonResponse({"message": "Booking canceled successfully!"})

        except json.JSONDecodeError:
            return JsonResponse({"error": "Invalid JSON data"}, status=400)

        except Exception as e:
            return JsonResponse({"error": str(e)}, status=500)
  