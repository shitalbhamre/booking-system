from django.urls import path
from .views import BookItemView, CancelBookingView

urlpatterns = [
    path('book/', BookItemView.as_view(), name='book-item'),
    path('cancel/', CancelBookingView.as_view(), name='cancel-booking'),
]
