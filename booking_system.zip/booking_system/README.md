# 📌 Booking System

This is a Django-based project for managing bookings.

## 🚀 Features
- 🔑 SimpleJWT authentication  
- 📂 CSV import functionality for members and inventory  
- 📅 Booking and cancellation system  

## 🛠 Installation

### 1️⃣ Clone the Repository
```sh
git clone https://github.com/your-username/your-repo.git
cd your-repo

2️⃣ Set Up a Virtual Environment & Install Dependencies
python -m venv venv
venv\Scripts\activate  # For Windows
pip install -r requirements.txt

3️⃣ Apply Migrations & Run the Server
python manage.py migrate
python manage.py runserver

🎯 Usage
🔐 1. Authentication
Obtain an access token by providing valid credentials.
curl -X POST http://127.0.0.1:8000/api/auth/token/ \
     -H "Content-Type: application/json" \
     -d '{"username": "<username>", "password": "<password>"}'

📥 2. Upload Members CSV
Upload a CSV file containing member details.
curl -X POST http://127.0.0.1:8000/api/upload/ \
     -H "Authorization: Bearer ACCESS_TOKEN" \
     -F "file=@input_data/members.csv"

📥 3. Upload Inventory CSV
Upload a CSV file containing inventory details.
curl -X POST http://127.0.0.1:8000/api/upload/ \
     -H "Authorization: Bearer ACCESS_TOKEN" \
     -F "file=@input_data/inventory.csv"

📌 4. Booking an Item
Book an inventory item for a member.
curl -X POST http://127.0.0.1:8000/api/bookings/book/ \
     -H "Authorization: Bearer ACCESS_TOKEN" \
     -H "Content-Type: application/json" \
     -d '{"member_id": 1, "inventory_id": 2}'

❌ 5. Canceling a Booking
Cancel an existing booking using its booking ID.
curl -X POST http://127.0.0.1:8000/api/bookings/cancel/ \
     -H "Authorization: Bearer ACCESS_TOKEN" \
     -H "Content-Type: application/json" \
     -d '{"booking_id": 5}'

