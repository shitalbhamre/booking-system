import csv
import io
from datetime import datetime
from django.http import JsonResponse
from django.utils.dateparse import parse_datetime
from django.views import View
from django.utils.decorators import method_decorator
from django.views.decorators.csrf import csrf_exempt
from inventory.models import Inventory
from members.models import Member

@method_decorator(csrf_exempt, name='dispatch')
class UploadCSVView(View):
    def post(self, request, *args, **kwargs):
        csv_file = request.FILES.get("file")
        if not csv_file:
            return JsonResponse({"error": "No file provided"}, status=400)

        if not csv_file.name.endswith(".csv"):
            return JsonResponse({"error": "Invalid file format. Please upload a CSV file."}, status=400)

        try:
            decoded_file = csv_file.read().decode("utf-8")
            io_string = io.StringIO(decoded_file)
            reader = csv.DictReader(io_string)

            headers = reader.fieldnames

            if set(headers) == {"name", "surname", "booking_count", "date_joined"}:
                return self.process_members_csv(reader)
            elif set(headers) == {"title", "description", "remaining_count", "expiration_date"}:
                return self.process_inventory_csv(reader)
            else:
                return JsonResponse({"error": "Invalid CSV format. Please upload a valid members.csv or inventory.csv."}, status=400)

        except Exception as e:
            return JsonResponse({"error": f"Error processing file: {str(e)}"}, status=500)

    def process_members_csv(self, reader):
        members_to_create = []

        for row in reader:
            try:
                booking_count = int(row["booking_count"].strip())
                date_joined = parse_datetime(row["date_joined"].strip())

                member = Member(
                    name=row["name"].strip(),
                    surname=row["surname"].strip(),
                    booking_count=booking_count,
                    date_joined=date_joined
                )
                members_to_create.append(member)

            except (KeyError, ValueError) as e:
                return JsonResponse({"error": f"Invalid data in row: {row}, Error: {str(e)}"}, status=400)

        Member.objects.bulk_create(members_to_create)

        return JsonResponse({"message": "Members CSV file uploaded successfully!"})

    def process_inventory_csv(self, reader):
        inventory_to_create = []

        for row in reader:
            try:
                expiration_date = datetime.strptime(row["expiration_date"].strip(), "%d/%m/%Y").date()
                remaining_count = int(row["remaining_count"].strip()) if row["remaining_count"].strip() else 0

                inventory_item = Inventory(
                    title=row["title"].strip(),
                    description=row["description"].strip() if row["description"].strip() else None,
                    remaining_count=remaining_count,
                    expiration_date=expiration_date
                )
                inventory_to_create.append(inventory_item)

            except (KeyError, ValueError) as e:
                return JsonResponse({"error": f"Invalid data in row: {row}, Error: {str(e)}"}, status=400)

        Inventory.objects.bulk_create(inventory_to_create)

        return JsonResponse({"message": "Inventory CSV file uploaded successfully!"})
